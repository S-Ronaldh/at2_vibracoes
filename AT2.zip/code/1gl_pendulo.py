import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from scipy.integrate import solve_ivp

m1 = 0.2495          
k1 = 23.56                   
c1 = 0.007

mp = 84.34 / 1000    
g = 9.81             

w_n = np.sqrt(k1 / m1)
L = g / (w_n**2)   
L = 14.4/100  

x0_predio = 0.04 
v0_predio = 0.0      
theta0 = 0.0         
omega0 = 0.0         

t_final = 10

def edos_sistema(t, y):
    x1, v1, theta, omega = y
    a1 = (-c1 * v1 - k1 * x1 + mp * g * theta) / m1
    alpha = -(a1 + g * theta) / L
    return [v1, a1, omega, alpha]

y0 = [x0_predio, v0_predio, theta0, omega0]
t_eval = np.linspace(0, t_final, int(t_final * 60)) 
solucao = solve_ivp(edos_sistema, (0, t_final), y0, t_eval=t_eval, method='RK45')

t = solucao.t
x_predio = solucao.y[0]
v_predio = solucao.y[1]
theta_pendulo = solucao.y[2]

a_predio = (-c1 * v_predio - k1 * x_predio + mp * g * theta_pendulo) / m1

H_andar = 0.8

fig = plt.figure(figsize=(12, 5))

ax_anim = plt.subplot2grid((1, 2), (0, 0))
ax_anim.set_xlim(-0.1, 0.1)
ax_anim.set_ylim(-0.1, H_andar + 0.2)
ax_anim.set_title("Animação Dinâmica: Prédio + Pêndulo", fontsize=12, fontweight='bold')
ax_anim.grid(True, linestyle=':')
ax_anim.axhline(0, color='black', lw=3) 

linhas_pilares, = ax_anim.plot([], [], color='blue', lw=3, label='Hastes (K)')
laje = plt.Rectangle((-0.03, H_andar - 0.015), 0.06, 0.03, color='dimgray', zorder=3)
ax_anim.add_patch(laje)
linha_cabo, = ax_anim.plot([], [], color='black', lw=1.5, zorder=4)
esfera_pendulo, = ax_anim.plot([], [], 'o', color='crimson', markersize=10, zorder=5, label='Pêndulo (Massa)')
ax_anim.legend(loc='upper right')

ax_graph_a = plt.subplot2grid((1, 2), (0, 1))
ax_graph_a.set_xlim(0, t_final)
ax_graph_a.set_ylim(np.min(a_predio)*1.2, np.max(a_predio)*1.2)
ax_graph_a.set_ylabel("Aceleração Prédio (m/s²)", fontweight='bold')
ax_graph_a.set_xlabel("Tempo (s)", fontweight='bold')
ax_graph_a.set_title("Histórico Temporal da Aceleração", fontsize=11, fontweight='bold')
ax_graph_a.grid(True, linestyle=':')
line_hist_a, = ax_graph_a.plot([], [], color='crimson', lw=1.5)

plt.tight_layout()

def init():
    linhas_pilares.set_data([], [])
    linha_cabo.set_data([], [])
    esfera_pendulo.set_data([], [])
    laje.set_x(-0.03)
    line_hist_a.set_data([], [])
    return [linhas_pilares, linha_cabo, esfera_pendulo, laje, line_hist_a]

def update(frame):
    xp = x_predio[frame]
    
    linhas_pilares.set_data([0, xp], [0, H_andar])
    laje.set_x(xp - 0.03)
    
    th = theta_pendulo[frame]
    x_esfera = xp + L * np.sin(th)
    y_esfera = H_andar - L * np.cos(th)
    
    linha_cabo.set_data([xp, x_esfera], [H_andar, y_esfera])
    esfera_pendulo.set_data([x_esfera], [y_esfera])
    
    tempo_atual = t[:frame]
    line_hist_a.set_data(tempo_atual, a_predio[:frame])
    
    return [linhas_pilares, linha_cabo, esfera_pendulo, laje, line_hist_a]

ani = FuncAnimation(fig, update, frames=len(t), init_func=init, blit=True, interval=16.6, repeat=False)
plt.show()