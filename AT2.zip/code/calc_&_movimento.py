import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from scipy.integrate import solve_ivp
from scipy.linalg import eigh

# 1. SOLVER DO SISTEMA DINÂMICO (N GRAUS DE LIBERDADE)
def resolver_n_dof(massas, rigidezes, amortecimentos, t_final, x0, v0, forca_params=None):
    N = len(massas)
    M = np.diag(massas)
    C = np.zeros((N, N))
    K = np.zeros((N, N))
    
    for i in range(N):
        K[i, i] = rigidezes[i] + (rigidezes[i+1] if i+1 < N else 0)
        C[i, i] = amortecimentos[i] + (amortecimentos[i+1] if i+1 < N else 0)
        if i+1 < N:
            K[i, i+1] = K[i+1, i] = -rigidezes[i+1]
            C[i, i+1] = C[i+1, i] = -amortecimentos[i+1]
            
    M_inv = np.linalg.inv(M)
    
    # --- ANÁLISE MODAL (Frequências e Modos) ---
    autovalores, autovetores = eigh(K, M)
    freq_rad = np.sqrt(autovalores)
    freq_hz = freq_rad / (2 * np.pi)
    
    print("\n" + "="*40)
    print("         RESULTADOS DA ANÁLISE MODAL        ")
    print("="*40)
    for j in range(N):
        print(f"\nModo de Vibração {j+1}:")
        print(f"  -> Frequência Natural (w_{j+1}): {freq_rad[j]:.4f} rad/s")
        print(f"  -> Frequência Natural (f_{j+1}): {freq_hz[j]:.4f} Hz")
        modo_normalizado = autovetores[:, j] / np.max(np.abs(autovetores[:, j]))
        print(f"  -> Forma Modal (phi_{j+1}): {modo_normalizado}")
    print("="*40 + "\n")
    
    # Definição das EDOs com vetor de força dinâmico
    def edos_sistema(t, y):
        x = y[:N]
        v = y[N:]
        
        F = np.zeros(N)
        
        # Se o usuário ativou a força externa, calcula o termo senoidal
        if forca_params and forca_params['ativo']:
            idx_andar = forca_params['andar'] - 1
            amp = forca_params['amplitude']
            w_f = forca_params['freq_rad']
            F[idx_andar] = amp * np.sin(w_f * t)
            
        a = M_inv @ (F - C @ v - K @ x)
        return np.concatenate((v, a))
    
    y0 = np.concatenate((x0, v0))
    t_eval = np.linspace(0, t_final, int(t_final * 50)) 
    solucao = solve_ivp(edos_sistema, (0, t_final), y0, t_eval=t_eval, method='RK45')
    
    x_sol = solucao.y[:N]
    v_sol = solucao.y[N:]
    
    # Recalcula as acelerações para a plotagem do ddx
    a_sol = np.zeros_like(x_sol)
    for i in range(len(solucao.t)):
        F_t = np.zeros(N)
        if forca_params and forca_params['ativo']:
            F_t[forca_params['andar']-1] = forca_params['amplitude'] * np.sin(forca_params['freq_rad'] * solucao.t[i])
        a_sol[:, i] = M_inv @ (F_t - C @ v_sol[:, i] - K @ x_sol[:, i])
        
    return solucao.t, x_sol, v_sol, a_sol

# --- INTERFACE DE ENTRADA DO USUÁRIO ---
print("="*60)
print("     CONFIGURAÇÃO DO PÓRTICO CISALHANTE (SHEAR BUILDING)     ")
print("="*60)

N_andares = int(input("Digite o número de graus de liberdade (andares): "))

perguntar_individual = input("\nDeseja definir valores diferentes para cada andar? (s/n): ").strip().lower()

if perguntar_individual == 's':
    m = []
    k = []
    c = []
    for i in range(N_andares):
        m.append(float(input(f" Massa do andar {i+1} (kg): ")))
        k.append(float(input(f" Rigidez lateral do andar {i+1} (N/m): ")))
        c.append(float(input(f" Amortecimento do andar {i+1} (N.s/m): ")))
else:
    m_padrao = float(input("\nDigite a massa padrão para TODOS os andares (kg): "))
    k_padrao = float(input("Digite a rigidez lateral padrão para TODOS os andares (N/m): "))
    c_padrao = float(input("Digite o amortecimento padrão para TODOS os andares (N.s/m): "))
    m = [m_padrao] * N_andares
    k = [k_padrao] * N_andares
    c = [c_padrao] * N_andares

# Configuração da Força Externa
print("\n--- Configuração de Força Externa ---")
forca_params = {'ativo': False}
ativar_forca = input("Deseja aplicar uma Força Harmônica Externa (F*sin(w*t))? (s/n): ").strip().lower()

if ativar_forca == 's':
    forca_params['ativo'] = True
    forca_params['andar'] = int(input(f"  Em qual andar a força será aplicada (1 até {N_andares})? "))
    forca_params['amplitude'] = float(input("  Qual a amplitude da força (N)? "))
    f_hz = float(input("  Qual a frequência da força em Hertz (Hz)? "))
    forca_params['freq_rad'] = f_hz * 2 * np.pi

# Condições Iniciais
print("\n--- Condições Iniciais ---")
x0 = []
v0 = [0.0] * N_andares

definir_x0 = input("Deseja aplicar um deslocamento inicial? (s/n): ").strip().lower()
if definir_x0 == 's':
    tipo_x0 = input("  Afastar apenas o topo (t) ou definir para cada andar (e)? ").strip().lower()
    if tipo_x0 == 't':
        desloc_topo = float(input("  Digite o deslocamento inicial do topo (m): "))
        x0 = [desloc_topo * (i+1) / N_andares for i in range(N_andares)]
    else:
        for i in range(N_andares):
            x0.append(float(input(f"  Deslocamento inicial do andar {i+1} (m): ")))
else:
    x0 = [0.0] * N_andares
    # Caso não tenha força ativa nem x0, aplica um pequeno pulso padrão para não iniciar travado
    if not forca_params['ativo']:
        x0[-1] = 0.05

t_final = float(input("\nDigite o tempo total de simulação em segundos (ex: 10): "))

print("\nProcessando equações dinâmicas...")
t, x_dados, v_dados, a_dados = resolver_n_dof(m, k, c, t_final, x0, v0, forca_params)

# --- CONFIGURAÇÃO DA TELA DA ANIMAÇÃO (SUBPLOTS) ---
fig = plt.figure(figsize=(14, 8))
ax_predio = plt.subplot2grid((3, 2), (0, 0), rowspan=3) 
ax_x   = plt.subplot2grid((3, 2), (0, 1))               
ax_dx  = plt.subplot2grid((3, 2), (1, 1))               
ax_ddx = plt.subplot2grid((3, 2), (2, 1))               

max_disp = max(np.max(np.abs(x_dados)), 0.01)
ax_predio.set_xlim(-max_disp * 2.2, max_disp * 2.2)
ax_predio.set_ylim(-0.5, N_andares + 0.5)
ax_predio.set_title(f"Movimento do Shear Building ({N_andares} DOF)", fontsize=12, fontweight='bold')
ax_predio.grid(True, linestyle=':')
chao = ax_predio.axhline(0, color='black', lw=3)
colunas_grafico, = ax_predio.plot([], [], color='blue', lw=2.5, zorder=1)

largura_laje = max_disp * 1.2
altura_laje = 0.12
blocos_lajes = []
for i in range(N_andares):
    laje = plt.Rectangle((-largura_laje/2, i + 1 - altura_laje/2), largura_laje, altura_laje, color='dimgray', zorder=2)
    ax_predio.add_patch(laje)
    blocos_lajes.append(laje)

andar_alvo = N_andares - 1 

for ax, titulo, cor, Y_lims in [
    (ax_x, f"Deslocamento $x_{N_andares}(t)$ (m)", "crimson", (np.min(x_dados[andar_alvo])*1.2, np.max(x_dados[andar_alvo])*1.2)),
    (ax_dx, f"Velocidade $\\dot{{x}}_{N_andares}(t)$ (m/s)", "teal", (np.min(v_dados[andar_alvo])*1.2, np.max(v_dados[andar_alvo])*1.2)),
    (ax_ddx, f"Aceleração $\\ddot{{x}}_{N_andares}(t)$ ($m/s^2$)", "darkorange", (np.min(a_dados[andar_alvo])*1.2, np.max(a_dados[andar_alvo])*1.2))
]:
    ax.set_xlim(0, t_final)
    ax.set_ylim(Y_lims)
    ax.set_ylabel(titulo)
    ax.grid(True, linestyle=':')
ax_ddx.set_xlabel("Tempo (s)")

line_x, = ax_x.plot([], [], color="crimson", lw=2)
line_dx, = ax_dx.plot([], [], color="teal", lw=2)
line_ddx, = ax_ddx.plot([], [], color="darkorange", lw=2)

def init():
    colunas_grafico.set_data([], [])
    line_x.set_data([], [])
    line_dx.set_data([], [])
    line_ddx.set_data([], [])
    for laje in blocos_lajes:
        laje.set_x(-largura_laje/2)
    return [colunas_grafico, line_x, line_dx, line_ddx] + blocos_lajes

def update(frame):
    dx = [0] + [x_dados[i][frame] for i in range(N_andares)]
    dy = list(range(N_andares + 1))
    colunas_grafico.set_data(dx, dy)
    
    for i, laje in enumerate(blocos_lajes):
        laje.set_x(dx[i+1] - largura_laje/2)
        
    tempo_atual = t[:frame]
    line_x.set_data(tempo_atual, x_dados[andar_alvo][:frame])
    line_dx.set_data(tempo_atual, v_dados[andar_alvo][:frame])
    line_ddx.set_data(tempo_atual, a_dados[andar_alvo][:frame])
    
    return [colunas_grafico, line_x, line_dx, line_ddx] + blocos_lajes

plt.ion()
ani = FuncAnimation(fig, update, frames=len(t), init_func=init, blit=True, interval=20, repeat=False)
plt.tight_layout()
plt.show(block=True)